package pac;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ProductTest {


    @Test
    void testCreateProduct() {
        Product product = new Product(1, "nokia", 100);
        Assertions.assertTrue(product.toString().contains("nokia"));
    }


    @Test
    void testProductToString() {
        Product product = new Product(1, "black barry", 3000);
        String toString = product.getName().toString();
        Assertions.assertTrue(toString.contains("black barry"));
    }

    @Test
    void testSetName() {
        Product product = new Product(1, "laptop", 500);
        product.setName("pc");
        Assertions.assertEquals(product.getName(), "pc");
    }

    @Test
    void testSetPrice() {
        Product product = new Product(1, "laptop", 500);
        product.setPrice(500/2);
        Assertions.assertEquals(product.getPrice(), 250);
    }

}